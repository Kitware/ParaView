# entry point for non in situ environments
from . import *
from paraview.simple import GenerateExtractsUsingCatalystOptions

# generate extracts
SaveExtractsUsingCatalystOptions(options)
