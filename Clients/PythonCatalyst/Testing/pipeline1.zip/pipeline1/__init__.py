r"init file"

# script generated using paraview version 5.8.1-RC1-852-gfcc2c90213

#--------------------------------------
# catalyst options
from paraview import catalyst
options = catalyst.Options()
options.ExtractsOutputDirectory = 'extracts'
options.GlobalTrigger = 'TimeStep'
options.CatalystLiveTrigger = 'TimeStep'

#--------------------------------------
# List individual modules with Catalyst analysis scripts
scripts = ['pipeline']

__all__ = scripts + ['options']
